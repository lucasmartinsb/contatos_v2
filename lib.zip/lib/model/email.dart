class Email {
  int id;
  String endereco;

  Email({required this.id, required this.endereco});

  Map<String, Object?> toMap() {
    return {'id': id, 'endereco': endereco};
  }

  factory Email.fromMap(Map<String, dynamic> map) {
    // Extrair os dados do mapa
    int id = map['id'];
    String endereco = map['endereco'];

    // Retornar uma instância de Email com os dados extraídos
    return Email(
      id: id,
      endereco: endereco,
    );
  }

  @override
  String toString() {
    return endereco;
  }
}
