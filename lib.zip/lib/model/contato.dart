import 'package:contatos_v2/model/email.dart';
import 'package:contatos_v2/model/telefone.dart';

class Contato {
  int id;
  String nome;
  String sobrenome;
  List<Email> emails;
  List<Telefone> telefones;

  Contato(
      {required this.id,
      required this.nome,
      required this.sobrenome,
      required this.emails,
      required this.telefones});

  Map<String, Object?> toMap() {
    return {
      'id': id,
      'nome': nome,
      'sobrenome': sobrenome,
    };
  }

  factory Contato.fromMap(Map<String, dynamic> map) {
    // Extrair os dados do mapa
    int id = map['id'];
    String nome = map['nome'];
    String sobrenome = map['sobrenome'];

    // Retornar uma instância de Contato com os dados extraídos
    return Contato(
      id: id,
      nome: nome,
      sobrenome: sobrenome,
      // Inicializar as listas de emails e telefones como vazias
      emails: [],
      telefones: [],
    );
  }

  @override
  String toString() {
    return '$nome $sobrenome, TELEFONES: $telefones';
  }
}
