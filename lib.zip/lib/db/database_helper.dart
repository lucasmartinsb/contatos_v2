import 'package:contatos_v2/model/contato.dart';
import 'package:contatos_v2/model/email.dart';
import 'package:contatos_v2/model/telefone.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DatabaseHelper {
  static const arquivoDoBancoDeDados = 'contatos.db';
  static const arquivoDoBancoDeDadosVersao = 1;

  static late Database db;

  iniciarDb() async {
    String databasesPath = await getDatabasesPath();
    String path = join(databasesPath, arquivoDoBancoDeDados);
    //databaseFactory.deleteDatabase(path);
    db = await openDatabase(path,
        version: arquivoDoBancoDeDadosVersao, onCreate: funcaoCriacaoBD);
    //deletarTodos();
  }

  Future funcaoCriacaoBD(Database db, int version) async {
    await db.execute('''
      CREATE TABLE Contatos (
        id INTEGER PRIMARY KEY,
        nome TEXT,
        sobrenome TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE Emails (
        id INTEGER PRIMARY KEY,
        idContato INTEGER,
        endereco TEXT,
        FOREIGN KEY (idContato) REFERENCES Contatos(id)
      )
    ''');

    await db.execute('''
      CREATE TABLE Telefones (
        id INTEGER PRIMARY KEY,
        idContato INTEGER,
        numero TEXT,
        FOREIGN KEY (idContato) REFERENCES Contatos(id)
      )
    ''');
  }

  Future<int> inserir(Map<String, dynamic> row) async {
    await iniciarDb();
    return await db.insert('Contatos', row);
  }

  Future<void> inserirTelefone(int idContato, String numero) async {
    await iniciarDb();
    // Insira o novo número na tabela Telefones
    await db.insert(
      'Telefones',
      {'idContato': idContato, 'numero': numero},
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<int> deletarTodos() async {
    await iniciarDb();
    return db.delete('Contato');
  }

  Future<Contato?> getContatoWithTelefonesAndEmails(int idContato) async {
    await iniciarDb();

    // Consulta para obter os dados do contato com base no ID
    List<Map<String, dynamic>> contatoMaps =
        await db.query('Contatos', where: 'id = ?', whereArgs: [idContato]);

    // Se o contato não existir, retorne null
    if (contatoMaps.isEmpty) {
      return null;
    }

    // Obtendo os dados do contato a partir do resultado da consulta
    Map<String, dynamic> contatoMap = contatoMaps.first;
    Contato contato = Contato.fromMap(contatoMap);

    // Consulta para obter os telefones do contato
    List<Map<String, dynamic>> telefoneMaps = await db
        .query('Telefones', where: 'idContato = ?', whereArgs: [idContato]);

    // Adicionando telefones ao contato
    List<Telefone> telefones = telefoneMaps.map((map) {
      return Telefone.fromMap(map);
    }).toList();
    contato.telefones = telefones;

    // Consulta para obter os emails do contato
    List<Map<String, dynamic>> emailMaps = await db
        .query('Emails', where: 'idContato = ?', whereArgs: [idContato]);

    // Adicionando emails ao contato
    List<Email> emails = emailMaps.map((map) {
      return Email.fromMap(map);
    }).toList();
    contato.emails = emails;

    return contato;
  }

  Future<List<Contato>> getAllContatosWithTelefonesAndEmails() async {
    await iniciarDb();
    // Consulta para obter todos os contatos
    List<Map<String, dynamic>> contatosMaps = await db.query('Contatos');

    // Lista para armazenar os contatos com telefones e e-mails
    List<Contato> contatosComTelefonesEEmails = [];

    // Iterando sobre os contatos
    for (var contatoMap in contatosMaps) {
      int idContato = contatoMap['id'];
      Contato? contato = await getContatoWithTelefonesAndEmails(idContato);
      if (contato != null) {
        contatosComTelefonesEEmails.add(contato);
      }
    }

    return contatosComTelefonesEEmails;
  }
}
