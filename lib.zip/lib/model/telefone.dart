class Telefone {
  int id;
  String numero;

  Telefone({required this.id, required this.numero});

  Map<String, Object?> toMap() {
    return {'id': id, 'numero': numero};
  }

  factory Telefone.fromMap(Map<String, dynamic> map) {
    // Extrair os dados do mapa
    int id = map['id'];
    String numero = map['numero'];

    // Retornar uma instância de Telefone com os dados extraídos
    return Telefone(
      id: id,
      numero: numero,
    );
  }

  @override
  String toString() {
    return numero;
  }
}
