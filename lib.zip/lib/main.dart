import 'dart:math';

import 'package:contatos_v2/db/database_helper.dart';
import 'package:contatos_v2/model/contato.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatefulWidget {
  const MainApp({super.key});

  @override
  State<MainApp> createState() => _MainAppState();
}

class _MainAppState extends State<MainApp> {
  var bdHelper = DatabaseHelper();
  final List<Contato> dados = [];

  void carregarContatosSalvos() async {
    var r = await bdHelper.getAllContatosWithTelefonesAndEmails();

    setState(() {
      dados.clear();
      dados.addAll(r);
    });
  }

  Future<void> inserirRegistro() async {
    var rnd = Random();

    final nomePessoa = 'Pessoa ${rnd.nextInt(999999)}';
    const sobrenomePessoa = 'silva';

    Map<String, dynamic> row = {
      'nome': nomePessoa,
      'sobrenome': sobrenomePessoa
    };

    final id = await bdHelper.inserir(row);

    print('Pessoa inserida com ID $id para $nomePessoa $sobrenomePessoa');

    carregarContatosSalvos();
  }

  void adicionarNumeroPadrao(int idContato) async {
    String numeroPadrao = '0000-0000';
    await bdHelper.inserirTelefone(idContato, numeroPadrao);
    carregarContatosSalvos();
  }

  @override
  void initState() {
    super.initState();
    carregarContatosSalvos();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Contatos V2'),
        ),
        body: SafeArea(
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Expanded(
                  child: ListView.builder(
                    itemCount: dados.length,
                    itemBuilder: (context, index) {
                      return ListTile(
                        title: Text(
                            dados[index].toString() ?? 'Nome não informado'),
                        onTap: () {
                          // Chamar a função para adicionar o número padrão
                          adicionarNumeroPadrao(dados[index].id);
                        },
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
        /*Utilizado o Builder para facilitar depois a navegação entre telas */
        floatingActionButton: Builder(
          builder: (BuildContext context) {
            return FloatingActionButton(
              child: const Icon(Icons.person_add),
              onPressed: () {
                inserirRegistro();
              },
            );
          },
        ),
      ),
    );
  }
}
